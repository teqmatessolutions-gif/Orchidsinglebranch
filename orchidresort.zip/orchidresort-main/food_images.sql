INSERT INTO food_item_images (item_id, image_url) VALUES 
(11, '/static/food_items/breakfast1.jpg'),
(12, '/static/food_items/breakfast2.jpg'),
(13, '/static/food_items/chicken.jpg'),
(14, '/static/food_items/curry.jpg'),
(15, '/static/food_items/fish.jpg'),
(16, '/static/food_items/pasta.jpg'),
(17, '/static/food_items/juice.jpg'),
(18, '/static/food_items/coffee.jpg'),
(19, '/static/food_items/sandwich.jpg'),
(20, '/static/food_items/samosa.jpg');
